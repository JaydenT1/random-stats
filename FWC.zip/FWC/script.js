async function fetchData() {
    try {
        let res = await fetch("https://raw.githubusercontent.com/JaydenT1/random-stats/refs/heads/main/fwc2026.json")
        let data = await res.json()
        return data
    } catch (err) {
        console.error(`Error fetching data: ${err}`)
    }
}

const countryCodes = {
    "USA": "us",
    "South Korea": "kr",
    "Scotland": "gb-sct",
    "Czechia": "cz",
    "Türkiye": "tr",
    "Côte d'Ivoire": "ci",
    "Iran": "ir",
    "DR Congo": "cd",
    "England": "gb-eng"
}

async function fetchCountryCode(name) {
    if (countryCodes.hasOwnProperty(name)){
        return countryCodes[name]
    }

    //fetch country data
    try {
        let res = await fetch("https://countries.dev/countries")
        let data = await res.json()
        let code = ""

        for (let country of Object.entries(data)) {
            
            if (country[1]["name"] == name) {
                code = country[1]["alpha2Code"]
                break
            }
        }
        return code.toLowerCase()

    } catch (err) {
        console.error(`Error fetching country data: ${err}`)
    }
}

async function getFlag(name, w=60, h=40) {
    let code = await fetchCountryCode(name)
    let flag = `https://flagcdn.com/h${h}/${code}.png`
    return `<figure class='hover-caption'><img src="${flag}" alt="${name}" width=${w}px><figcaption style="display:none">${name}</figcaption></figure>`
}


//--------------------------------------------------------------------------
//Host Flags
async function getHostFlags(){
    let data = await fetchData()
    const hostFlagsDisplay = document.getElementById("host-flags")
    for (let country of data.hosts){
        hostFlagsDisplay.innerHTML += await getFlag(country,80,40)
    }
}
getHostFlags()

const groupDisplay = document.getElementById("group-display")
const knockoutDisplay = document.getElementById("knockout-display")
groupDisplay.style.display = "none"
let teamStats = []

function getScore(data, group, teams){
    let result = []
    let thisGroupStats = []
    //console.log(data.matches.group.length) //total number of group matches
    for (let team of teams){
        let score = {}
        let gf = 0, ga = 0
        
        for (let match of data.matches.group){
            let matchScore = match["score"].split("-")

            if (match.team1 == team){
                score[teams.indexOf(match.team2)] = match["score"]
                gf += Number(matchScore[0])
                ga += Number(matchScore[1])

            } else if (match.team2 == team){
                score[teams.indexOf(match.team1)] = matchScore[1] + "-" + matchScore[0]
                gf += Number(matchScore[1])
                ga += Number(matchScore[0])
            }
        }

        score["gf"] = gf
        score["ga"] = ga
        score["gd"] = gf - ga

        //save team stats
        let thisTeamStats = {}
        thisTeamStats["name"] = team
        thisTeamStats["groupName"] = group
        thisTeamStats["gf"] = gf
        thisTeamStats["ga"] = ga
        thisTeamStats["gd"] = gf - ga
        thisGroupStats.push(thisTeamStats)
        result.push(score)
    }
    teamStats.push(thisGroupStats)
    return result
}

let thirdPlaces = []
async function getThirdPlaces(){
    const groupTables = groupDisplay.querySelectorAll("table")

    //Sort teams by pts
    for (let group of teamStats){
        group.sort((a,b) => b.pts - a.pts || b.gd - a.gd || b.gf - a.gf)
    }

    //console.log(teamStats)
    for (let group of teamStats){
        thirdPlaces.push(group[2])
    }
    thirdPlaces.sort((a,b) => b.pts - a.pts || b.gd - a.gd || b.gf - a.gf)
    //console.log(thirdPlaces)

    let result = "<table><tr><th>Top 3rd Places</th><th>GF</th><th>GA</th><th>GD</th><th>Pts</th></tr>"
    for (let team of thirdPlaces){
        result += `<tr><td>${await getFlag(team.name)}</td><td>${team["gf"]}</td><td>${team["ga"]}</td><td>${team["gd"]}</td><td>${team["pts"]}</td></tr>`
    }
    result += "</table>"
    groupDisplay.innerHTML += result
}

async function displayKnockout(data, n){
    //n is the number of teams after group stage
    //i.e. 32 teams (round of 32)

    let powerOf2 = Math.log(n)/Math.log(2)
    let rows = n/2
    
    for (let i = powerOf2; i > 1; i--){
        
        let resultLeft = `<div style='order: ${-i}; gap: ${20 * (1 + Math.abs(i - powerOf2)*6)}px;  margin: auto 10px'>`
        let resultRight = `<div style='order: ${i}; gap: ${20 * (1 + Math.abs(i - powerOf2)*6)}px;  margin: auto 10px'>`

        for (let k = 0; k < rows; k+=2){
            resultLeft += `<div class='knockout-match'><div>${await getFlag(data["qualified" + 2**i][k],30,20)}${await getFlag(data["qualified" + 2**i][k+1],30,20)}</div></div>`
            resultRight += `<div class='knockout-match reversed'><div>${await getFlag(data["qualified" + 2**i][k + Math.ceil(2**i/2)],30,20)}${await getFlag(data["qualified" + 2**i][k+1 + Math.ceil(2**i/2)],30,20)}</div></div>`
        }
        resultLeft += "</div>"
        resultRight += "</div>"
        knockoutDisplay.innerHTML += resultLeft + resultRight

        rows /= 2
    }

    //Final & Third place
    let resultFinal = `<div style='order: 1; margin: auto 10px'><p id='championP'>The champion is...<br><b>Spain</b></p>`
    resultFinal += `<div class='knockout-match final'><div>${await getFlag(data["final"][0])}${await getFlag(data["final"][1])}</div></div>`
    resultFinal += `<div class='knockout-match third-place'><div>${await getFlag(data["thirdPlace"][0])}${await getFlag(data["thirdPlace"][1])}</div></div>`
    resultFinal += "</div>"
    knockoutDisplay.innerHTML += resultFinal

}

async function addKnockoutScores(data){
    let matches = knockoutDisplay.querySelectorAll(".knockout-match")
    for (let match of matches){
        let team1 = match.querySelector("div").querySelector("figure").querySelector("img").getAttribute("alt")
        let team2 = match.querySelector("div").querySelectorAll("figure")[1].querySelector("img").getAttribute("alt")
        let added = false

        let triangleDirection = match.parentElement.style.order <= 0 ? "R" : "L" //L or R
        let triangle = `<div class='triangle${triangleDirection}'></div>`

        let scoreDiv = "<div class='knockout-score'"
        if (triangleDirection == "L"){
            scoreDiv += " style='align-items: flex-end'>"
        } else {scoreDiv += " style='align-items: flex-start'>"}

        for (let matchData of data.matches.knockout){
            let matchScore = matchData["score"].split("-")

            if (matchData.team1 == team1 && matchData.team2 == team2){
                /*scoreDiv += `<p>${matchScore[0]}</p><p>${matchScore[1]}</p>`*/
                
                if (Number(matchScore[0]) > Number(matchScore[1])){
                    if (triangleDirection == "L"){
                        scoreDiv += `<div>${triangle}${matchScore[0]}</div><p>${matchScore[1]}</p>`
                    } else {scoreDiv += `<div>${matchScore[0]}${triangle}</div><p>${matchScore[1]}</p>`}

                } else {

                    if (triangleDirection == "L"){
                        scoreDiv += `<p>${matchScore[0]}</p><div>${triangle}${matchScore[1]}</div>`
                    } else {scoreDiv += `<p>${matchScore[0]}</p><div>${matchScore[1]}${triangle}</div>`}}
                added = true

                break

            } else if (matchData.team2 == team1 && matchData.team1 == team2) {

                if (Number(matchScore[1]) > Number(matchScore[0])){
                    if (triangleDirection == "L"){
                        scoreDiv += `<div>${triangle}${matchScore[1]}</div><p>${matchScore[0]}</p>`
                    } else {scoreDiv += `<div>${matchScore[1]}${triangle}</div><p>${matchScore[0]}</p>`}

                } else {
                    
                    if (triangleDirection == "L"){
                        scoreDiv += `<p>${matchScore[1]}</p><div>${triangle}${matchScore[0]}</div>`
                    } else {scoreDiv += `<p>${matchScore[1]}</p><div>${matchScore[0]}${triangle}</div>`}}

                added = true

                break
            }
        }

        if (!added){
            scoreDiv += `<p>/</p><p>/</p>`
        }
        scoreDiv += "</div>"
        match.innerHTML += scoreDiv
    }
}

async function displayGroups(data) {

    for (let [group, teams] of Object.entries(data.groups)) { 

        //getScore
        let [t0Scores, t1Scores, t2Scores, t3Scores] = getScore(data, group, teams)
 
        groupDisplay.innerHTML += `
        <table>
        <tr><td>${group.toUpperCase()}</td><td>${await getFlag(teams[0])}</td><td>${await getFlag(teams[1])}</td><td>${await getFlag(teams[2])}</td><td>${await getFlag(teams[3])}</td><td>GF</td><td>GA</td><td>GD</td><td>Pts</td></tr>
        <tr><td>${await getFlag(teams[0])}</td><td>/</td><td>${t0Scores[1]}</td><td>${t0Scores[2]}</td><td>${t0Scores[3]}</td><td>${t0Scores["gf"]}</td><td>${t0Scores["ga"]}</td><td>${t0Scores["gd"]}</td><td></td></tr>
        <tr><td>${await getFlag(teams[1])}</td><td>${t1Scores[0]}</td><td>/</td><td>${t1Scores[2]}</td><td>${t1Scores[3]}</td><td>${t1Scores["gf"]}</td><td>${t1Scores["ga"]}</td><td>${t1Scores["gd"]}</td><td></td></tr>
        <tr><td>${await getFlag(teams[2])}</td><td>${t2Scores[0]}</td><td>${t2Scores[1]}</td><td>/</td><td>${t2Scores[3]}</td><td>${t2Scores["gf"]}</td><td>${t2Scores["ga"]}</td><td>${t2Scores["gd"]}</td><td></td></tr>
        <tr><td>${await getFlag(teams[3])}</td><td>${t3Scores[0]}</td><td>${t3Scores[1]}</td><td>${t3Scores[2]}</td><td>/</td><td>${t3Scores["gf"]}</td><td>${t3Scores["ga"]}</td><td>${t3Scores["gd"]}</td><td></td></tr>
        </table>`
    }

    //color scores
    const groupTables = groupDisplay.querySelectorAll("table")
    for (let table of groupTables){
        let tbody = table.querySelector("tbody")
        let rows = tbody.querySelectorAll("tr")
        
        for (let r = 1; r < 5; r++){
            let cells = rows[r].querySelectorAll("td")
            let pts = 0

            for (let td = 1; td < 5; td++){
                let score = cells[td].textContent

                if (score != "/"){
                    scoreSplit = score.split("-")
                    if (scoreSplit[0] > scoreSplit[1]){
                        cells[td].style.cssText += "border: 2px solid green"
                        pts += 3
                    } else if (scoreSplit[0] < scoreSplit[1]){
                        cells[td].style.cssText += "border: 2px solid red"
                    } else {
                        cells[td].style.cssText += "border: 2px solid white"
                        pts += 1
                    }
                }
            }
            cells[8].textContent = pts
            //save pts to team stats
            let groupName = rows[0].querySelector("td").textContent
            let teamName = cells[0].querySelector("figure").querySelector("img").getAttribute("alt")
            for (let group of teamStats){
                if (group[0].groupName == groupName.toLowerCase()){
                    for (let team of group){
                        if (team.name == teamName){
                            team["pts"] = pts
                        }
                    }
                }
            }

        }
    }
    //console.log(teamStats)
    await getThirdPlaces()
    await displayKnockout(data,32)
    await addKnockoutScores(data)

}



async function displayData(){
    let data = await fetchData()
    displayGroups(data)

}

displayData()



//Tab Buttons
const tablist = document.getElementById("tablist")
const tabBtns = document.querySelectorAll(".tab-btn")
const tabs = document.querySelector("main").querySelectorAll("div")
function tabChange(element){
    for (let tab of tabs){
        tab.style.display = "none"
    }

    let tabBtnId = element.id.split("-")
    let tabName = tabBtnId[0] + "-" + "display"
    if (tabName == "group-display"){
        document.getElementById(tabName).style.display = "grid"
        document.body.style.background = "radial-gradient(rgb(119, 152, 196),rgb(88, 135, 196))"
    } else {
        document.getElementById(tabName).style.display = "flex"
        document.body.style.background = "radial-gradient(rgb(236, 216, 126),rgb(201, 180, 91))"
    }
}

