async function fetchData() {
    try {
        let res = await fetch("https://raw.githubusercontent.com/JaydenT1/random-stats/refs/heads/main/fwc2026.json")
        let data = await res.json()
        return data
    } catch (err) {
        console.error(`Error fetching data: ${err}`)
    }
}

const countryCodes = {
    "USA": "us",
    "South Korea": "kr",
    "Scotland": "gb-sct",
    "Czechia": "cz",
    "Türkiye": "tr",
    "Côte d'Ivoire": "ci",
    "Iran": "ir",
    "DR Congo": "cd",
    "England": "gb-eng"
}

async function fetchCountryCode(name) {
    if (countryCodes.hasOwnProperty(name)) {
        return countryCodes[name]
    }

    //fetch country data
    try {
        let res = await fetch("https://countries.dev/countries")
        let data = await res.json()
        let code = ""

        for (let country of Object.entries(data)) {

            if (country[1]["name"] == name) {
                code = country[1]["alpha2Code"]
                break
            }
        }
        return code.toLowerCase()

    } catch (err) {
        console.error(`Error fetching country data: ${err}`)
    }
}

async function getFlag(name, w = 60, h = 40) {
    let code = await fetchCountryCode(name)
    let flag = `https://flagcdn.com/h${h}/${code}.png`
    return `<figure class='hover-caption'><img src="${flag}" alt="${name}" width=${w}px><figcaption style="display:none">${name}</figcaption></figure>`
}

//--------------------------------------------------------------------------
//Host Flags
async function getHostFlags() {
    let data = await fetchData()
    const hostFlagsDisplay = document.getElementById("host-flags")
    for (let country of data.hosts) {
        hostFlagsDisplay.innerHTML += await getFlag(country, 80, 40)
    }
}
getHostFlags()
//--------------------------------------------------------------------------

//Tab Buttons
const tablist = document.getElementById("tablist")
const tabBtns = document.querySelectorAll(".tab-btn")
const rankingsDisplay = document.getElementById("rankings-display")
const tabs = rankingsDisplay.querySelectorAll("div")
function tabChange(element){
    for (let tab of tabs){
        tab.style.display = "none"
    }

    let tabBtnId = element.id.split("-")
    let tabName = tabBtnId[0] + "-" + "display"
    document.getElementById(tabName).style.display = "flex"
}

//--------------------------------------------------------------------------
document.body.style.background = "linear-gradient(rgb(105, 192, 105),rgb(87, 167, 87))"
const teamsDisplay = document.getElementById("teams-display")
const goalsDisplay = document.getElementById("goals-display")
goalsDisplay.style.display = "none"

let teamRankings = []

function getTeamRecords(data){

    for (let [groupName, teams] of Object.entries(data.groups)){
            for (let team of teams){
                let teamStats = {}
                teamStats["name"] = team
                teamStats["mp"] = 0
                teamStats["w"] = 0
                teamStats["d"] = 0
                teamStats["l"] = 0 
                teamStats["gf"] = 0
                teamStats["ga"] = 0
                teamStats["pts"] = 0
                teamStats["yc"] = 0
                teamStats["rc"] = 0
                
                //Search for team match records
                for (let [stage, matches] of Object.entries(data.matches)){
                    for (let match of matches){
                        let matchScore = match.score.split("-")
                        //Remove penalty scores
                        if (matchScore[0].slice(-1) == ")"){
                            matchScore[0] = matchScore[0].slice(0,-3)
                            matchScore[1] = matchScore[1].slice(0,-3)
                        }
                        
                        if (match.team1 == team){
                            teamStats["mp"] ++
                            teamStats["gf"] += Number(matchScore[0])
                            teamStats["ga"] += Number(matchScore[1])

                            if (Number(matchScore[0]) > Number(matchScore[1])){
                                teamStats["w"] ++               
                                teamStats["pts"] += 3          
                            } else if (Number(matchScore[0]) < Number(matchScore[1])){
                                teamStats["l"] ++
                            } else {
                                teamStats["d"] ++
                                teamStats["pts"] += 1
                            }

                            //cards
                            teamStats["rc"] += match.redCards[0].length
                            teamStats["yc"] += match.yellowCards[0].length

                        } else if (match.team2 == team){
                            teamStats["mp"] ++
                            teamStats["gf"] += Number(matchScore[1])
                            teamStats["ga"] += Number(matchScore[0])

                            if (Number(matchScore[0]) > Number(matchScore[1])){
                                teamStats["l"] ++                      
                            } else if (Number(matchScore[0]) < Number(matchScore[1])){
                                teamStats["w"] ++
                                teamStats["pts"] += 3
                            } else {
                                teamStats["d"] ++
                                teamStats["pts"] += 1
                            }

                            //cards
                            teamStats["rc"] += match.redCards[1].length
                            teamStats["yc"] += match.yellowCards[1].length
                        }
                    }
                }
                teamStats["gd"] = teamStats["gf"] - teamStats["ga"]
                teamRankings.push(teamStats)
            }
        }

    
}

async function displayTeams(){
    let data = await fetchData()
    let headerRow = "<tr class='header-row'><th>Ranking</th><th>Teams</th><th>MP</th><th>W</th><th>D</th><th>L</th><th>GF</th><th>GA</th><th>GD</th><th><div class='yellow-card-icon' style='margin: 0 30%'></div></th><th><div class='red-card-icon' style='margin: 0 30%'></div></th><th>Pts</th></tr>"
    let result = "<div id='team-rankings'><h2>Teams</h2><table>" + headerRow

    //Fill in teamRankings
    await getTeamRecords(data)

    //Sort team rankings
    teamRankings.sort((a,b) => b.mp - a.mp || b.pts - a.pts || b.gd - a.gd || b.gf - a.gf)
    
    //Display
    let ranking = 1
    for (let team of teamRankings){
        result += `<tr><td>#${ranking}</td><td>${await getFlag(team["name"])}</td><td>${team["mp"]}</td><td>${team["w"]}</td><td>${team["d"]}</td><td>${team["l"]}</td>`
        result += `<td>${team["gf"]}</td><td>${team["ga"]}</td><td>${team["gd"]}</td>`
        result += `<td>${team["yc"]}</td><td>${team["rc"]}</td><td>${team["pts"]}</td></tr>`
        ranking ++

        if ((ranking - 1)%4 == 0){
            //Not the end of the rankings
            if (ranking >= teamRankings.length){
                break
            }
            result += headerRow
        }
    }

    result += "</table></div>"
    teamsDisplay.innerHTML += result
}

displayTeams()

let playerStats = []

function getPlayerStats(data){

    for (let [stage, matches] of Object.entries(data.matches)){
        for (let match of matches){
            for (let teamGoals of match.goals){
                for (let goal of teamGoals){
                    let goalSplit = goal.split(" ")
                    let isOwnGoal = goalSplit[0].slice(0,4) == "(OG)"
                    let numOfGoals = goalSplit[0].split(",").length
                    let playerName = goalSplit
                    playerName.shift()
                    playerName = playerName.join(" ")
                    
                    //Check if player already exists in playerStats
                    let found = false
                    for (let player of playerStats){
                        if (player.name == playerName){
                            found = true
                            if (isOwnGoal){
                                player["ownGoals"] += numOfGoals
                            } else {player["goals"] += numOfGoals}
                        }
                    }

                    if (!found){
                        let thisStat = {}
                        thisStat["name"] = playerName
                        let teamIndex = match.goals.indexOf(teamGoals) + 1
                        
                        //console.log(match[`team${teamIndex}`])
                        thisStat["goals"] = 0
                        thisStat["ownGoals"] = 0

                        if (isOwnGoal){
                            thisStat["ownGoals"] += numOfGoals
                            thisStat["goals"] = 0
                            if (teamIndex == 2){
                                thisStat["team"] = match[`team1`]
                            } else {thisStat["team"] = match[`team2`]}
                        } else {
                            thisStat["goals"] += numOfGoals
                            thisStat["ownGoals"] = 0
                            thisStat["team"] = match[`team${teamIndex}`]
                        }
                        thisStat["redCards"] = 0
                        thisStat["yellowCards"] = 0
                        playerStats.push(thisStat)
                    }

                }
            }
            //red cards
            for (let teamCards of match.redCards){
                for (let card of teamCards){
                    let cardSplit = card.split(" ")
                    let playerName = cardSplit
                    playerName.shift()
                    playerName = playerName.join(" ")
                    
                    //Check if player already exists in playerStats
                    let found = false
                    for (let player of playerStats){
                        if (player.name == playerName){
                            found = true
                            player["redCards"] ++
                        }
                    }

                    if (!found){
                        let thisStat = {}
                        thisStat["name"] = playerName
                        let teamIndex = match.redCards.indexOf(teamCards) + 1
                        thisStat["team"] = match[`team${teamIndex}`]
                        thisStat["goals"] = 0
                        thisStat["ownGoals"] = 0
                        
                        thisStat["redCards"] = 1
                        thisStat["yellowCards"] = 0
                        playerStats.push(thisStat)
                    }
                }
            }
            //yellow cards
            for (let teamCards of match.yellowCards){
                for (let card of teamCards){
                    let cardSplit = card.split(" ")
                    let playerName = cardSplit
                    playerName.shift()
                    playerName = playerName.join(" ")
                    
                    //Check if player already exists in playerStats
                    let found = false
                    for (let player of playerStats){
                        if (player.name == playerName){
                            found = true
                            player["yellowCards"] ++
                        }
                    }

                    if (!found){
                        let thisStat = {}
                        thisStat["name"] = playerName
                        let teamIndex = match.yellowCards.indexOf(teamCards) + 1
                        thisStat["team"] = match[`team${teamIndex}`]
                        thisStat["goals"] = 0
                        thisStat["ownGoals"] = 0
                        
                        thisStat["redCards"] = 0
                        thisStat["yellowCards"] = 1
                        playerStats.push(thisStat)
                    }
                }
            }
        }
    }
}

async function displayGoals(){
    //Display goals (and cards)
    let data = await fetchData()
    let result = "<div id='goal-rankings'><h2>Goals</h2><table><tr><th>Goals</th><th>Player</th></tr>"
    const color1 = "rgb(40,40,40)"
    const color2 = "rgb(60,60,60)"

    await getPlayerStats(data)

    //Sort by goals
    playerStats.sort((a,b) => b.goals - a.goals || a.name.localeCompare(b.name))
    
    //Display
    let maxGoals = playerStats[0].goals
    let addedPlayers = 0
    let rowColor = color2
    for (let g = maxGoals; g > 0; g--){
        const numOfPlayers = playerStats.filter(p => p.goals == g).length

        if (numOfPlayers == 0){continue}

        for (let p = 1; p <= numOfPlayers; p++){
            result += `<tr style="background-color: ${rowColor}">`

            if (p == 1){
                result += `<td rowspan="${numOfPlayers}">${g}</td>`
            }
            result += `<td>${await getFlag(playerStats[addedPlayers].team, 30, 20)}${playerStats[addedPlayers].name}</td></tr>`
            addedPlayers ++
        }

        if (rowColor == color2){
            rowColor = color1
        } else {rowColor = color2}
    }
   
    result += "</table></div>"
    goalsDisplay.innerHTML += result
    //----------------------------------------------------------
    //Sort by own goals
    const OGPlayers = playerStats.filter(p => p.ownGoals > 0)
    OGPlayers.sort((a,b) => b["ownGoals"] - a["ownGoals"] || a.name.localeCompare(b.name))
    
    //Display
    result = "<div id='own-goal-rankings'><h2>Own Goals</h2><table><tr><th>Own Goals</th><th>Player</th></tr>"
    let maxOwnGoals = OGPlayers[0].ownGoals
    addedPlayers = 0
    rowColor = color2

    for (let g = maxOwnGoals; g > 0; g--){
        const numOfPlayers = OGPlayers.filter(p => p.ownGoals == g).length
        if (numOfPlayers == 0){continue}
        
        for (let p = 1; p <= numOfPlayers; p++){
            result += `<tr style="background-color: ${rowColor}">`

            if (p == 1){
                result += `<td rowspan="${numOfPlayers}">${g}</td>`
            }
            result += `<td>${await getFlag(OGPlayers[addedPlayers].team, 30, 20)}${OGPlayers[addedPlayers].name}</td></tr>`
            addedPlayers ++
        }

        if (rowColor == color2){
            rowColor = color1
        } else {rowColor = color2}
    }
    result += "</table></div>"
    goalsDisplay.innerHTML += result
    //----------------------------------------------------------
    //Sort by yellow cards
    playerStats.sort((a,b) => b.yellowCards - a.yellowCards || a.name.localeCompare(b.name))

    //Display
    result = "<div id='y-card-rankings'><h2>Yellow Cards</h2><table><tr><th>Yellow Cards</th><th>Player</th></tr>"
    let maxYellowCards = playerStats[0].yellowCards
    addedPlayers = 0
    rowColor = color2

    for (let c = maxYellowCards; c > 0; c--){
        const numOfPlayers = playerStats.filter(p => p.yellowCards == c).length
        if (numOfPlayers == 0){continue}
        
        for (let p = 1; p <= numOfPlayers; p++){
            result += `<tr style="background-color: ${rowColor}">`

            if (p == 1){
                result += `<td rowspan="${numOfPlayers}">${c}</td>`
            }
            result += `<td>${await getFlag(playerStats[addedPlayers].team, 30, 20)}${playerStats[addedPlayers].name}</td></tr>`
            addedPlayers ++
        }

        if (rowColor == color2){
            rowColor = color1
        } else {rowColor = color2}
    }
    result += "</table></div>"
    goalsDisplay.innerHTML += result

    //----------------------------------------------------------
    //Sort by red cards
    playerStats.sort((a,b) => b.redCards - a.redCards || a.name.localeCompare(b.name))

    //Display
    result = "<div id='card-rankings'><h2>Red Cards</h2><table><tr><th>Red Cards</th><th>Player</th></tr>"
    let maxRedCards = playerStats[0].redCards
    addedPlayers = 0
    rowColor = color2

    for (let c = maxRedCards; c > 0; c--){
        const numOfPlayers = playerStats.filter(p => p.redCards == c).length
        if (numOfPlayers == 0){continue}
        
        for (let p = 1; p <= numOfPlayers; p++){
            result += `<tr style="background-color: ${rowColor}">`

            if (p == 1){
                result += `<td rowspan="${numOfPlayers}">${c}</td>`
            }
            result += `<td>${await getFlag(playerStats[addedPlayers].team, 30, 20)}${playerStats[addedPlayers].name}</td></tr>`
            addedPlayers ++
        }

        if (rowColor == color2){
            rowColor = color1
        } else {rowColor = color2}
    }
    result += "</table></div>"
    goalsDisplay.innerHTML += result
}

displayGoals()
