async function fetchData() {
    try {
        let res = await fetch("https://raw.githubusercontent.com/JaydenT1/random-stats/refs/heads/main/fwc2026.json")
        let data = await res.json()
        return data
    } catch (err) {
        console.error(`Error fetching data: ${err}`)
    }
}

const countryCodes = {
    "USA": "us",
    "South Korea": "kr",
    "Scotland": "gb-sct",
    "Czechia": "cz",
    "Türkiye": "tr",
    "Côte d'Ivoire": "ci",
    "Iran": "ir",
    "DR Congo": "cd",
    "England": "gb-eng"
}

async function fetchCountryCode(name) {
    if (countryCodes.hasOwnProperty(name)) {
        return countryCodes[name]
    }

    //fetch country data
    try {
        let res = await fetch("https://countries.dev/countries")
        let data = await res.json()
        let code = ""

        for (let country of Object.entries(data)) {

            if (country[1]["name"] == name) {
                code = country[1]["alpha2Code"]
                break
            }
        }
        return code.toLowerCase()

    } catch (err) {
        console.error(`Error fetching country data: ${err}`)
    }
}

async function getFlag(name, w = 60, h = 40) {
    let code = await fetchCountryCode(name)
    let flag = `https://flagcdn.com/h${h}/${code}.png`
    return `<figure><img src="${flag}" alt="${name}" width=${w}px><figcaption style="display:none">${name}</figcaption></figure>`
}

//--------------------------------------------------------------------------
//Host Flags
async function getHostFlags() {
    let data = await fetchData()
    const hostFlagsDisplay = document.getElementById("host-flags")
    for (let country of data.hosts) {
        hostFlagsDisplay.innerHTML += await getFlag(country, 80, 40)
    }
}
getHostFlags()

document.body.style.background = "linear-gradient(rgb(105, 192, 105),rgb(87, 167, 87))"
const matchesDisplay = document.getElementById("matches-display")
const matchDetails = document.getElementById("match-details")
const matchOverlay = document.getElementById("match-overlay")
matchOverlay.style.display = "none"
matchDetails.style.display = "none"

function getStageName(stage, data, match) {
    let stageName = ""

    if (stage == "group") {
        let group = ""
        stageName = "Group Stage"
        for (let [k, v] of Object.entries(data.groups)) {
            if (v.includes(match.team1) || v.includes(match.team2)) {
                group = "Group " + k.toUpperCase()
                break
            }
        }
        return [stageName, group]

    } else {
        if (Number(match.stage) >= 16) {
            stageName = "Round of " + match.stage
        } else {
            stageName = match.stage
        }
        return [stageName, ""]
    }
}

async function displayMatches() {
    let data = await fetchData()
    let dateGroup

    for (let [stage, matches] of Object.entries(data.matches)) {
        dateGroup = matches[0].date
        let dateMatches = ""

        for (let match of matches) {
            if (matches.indexOf(match) == 0) {
                dateId = match.date.split(" ").join("-")
                dateMatches += `<div id='matches-${dateId}'><p>${match.date}</p><div>`
            } else if (match.date != dateGroup) {
                dateGroup = match.date
                dateId = match.date.split(" ").join("-")
                matchesDisplay.innerHTML += dateMatches + "</div></div>"
                dateMatches = `<div id='matches-${dateId}'><p>${match.date}</p><div>`
            }

            let [stageName, group] = getStageName(stage, data, match)

            dateMatches += `<button class='match-display' onclick='displayMatch2(this)'><div><div>${await getFlag(match.team1)}<p>${match.score}</p>${await getFlag(match.team2)}</div><div><p class='stage-name'>${stageName}</p>|<p class='group-name'>${group}</p>`
            if (group) { dateMatches += "|" }
            dateMatches += `<p>${match.stadium}</p></div></div></button>`
        }
        matchesDisplay.innerHTML += dateMatches + "</div></div>"

    }
}
displayMatches()

function getGoals(match, teamIndex) {
    //get goals and cards
    let goalResult = "<div class='goals'>"
    for (let player of match.goals[teamIndex]) {
        if(player.slice(0,4) == "(OG)"){
            goalResult += `<div class='match-goal'><img src='Football.svg' alt='Goal' class='football-icon OG'><p>${player}</p></div>`
        } else {
            goalResult += `<div class='match-goal'><img src='Football.svg' alt='Goal' class='football-icon'><p>${player}</p></div>`
        }
    }
    goalResult += "</div>"

    let redCardResult = "<div class='red-cards'>"
    for (let player of match.redCards[teamIndex]) {
        redCardResult += `<div class='match-red-card'><div class='red-card-icon'></div><p>${player}</p></div>`
    }
    redCardResult += "</div>"

    let yellowCardResult = "<div class='yellow-cards'>"
    for (let player of match.yellowCards[teamIndex]) {
        yellowCardResult += `<div class='match-yellow-card'><div class='yellow-card-icon'></div><p>${player}</p></div>`
    }
    yellowCardResult += "</div>"

    return `<div>${goalResult}${redCardResult}${yellowCardResult}</div>`
}

function getPlayerStatus(match, playerName){
    result = ""
    //Goals
    for (let t of match.goals){
        for (let playerGoal of t){
            if (playerGoal.includes(playerName)){
                result += "<img src='Football.svg' alt='Goal'>"
            }
        }
    }

    //Red cards
    for (let t of match.redCards){
        for (let playerCard of t){
            if (playerCard.includes(playerName)){
                result += "<div class='red-card-icon'></div>"
            }
        }
    }

    //Sub
    for (let subPlayer of match.subOut){
        if (subPlayer.includes(playerName)){
            result += "<div class='triangleDown'></div>"
        }
    }

    return result
}

function getPlayers(match){
    let field = document.getElementById("football-field")

    let t = 0
    for (let [formation, starters] of Object.entries(match.starters)){
        field.querySelectorAll(".penalty-area")[t].innerHTML += `<div class='player-tag'><p><b>${starters[0].slice(0,2)}</b>${starters[0].slice(2)}</p></div>`

        let added = 0
        formationOrder = formation.split("-")
        for (let k = 0; k < formationOrder.length; k++){
            let result = "<div>"
            for (let i = 1; i <= Number(formationOrder[k]); i++){
                result += `<div class='player-tag'><p><b>${starters[i + added].slice(0,2)}</b>${starters[i + added].slice(2)}</p>`
                result += getPlayerStatus(match, starters[i + added].slice(2).trim())
                result += "</div>"
            }
            added += Number(formationOrder[k])
            result += "</div>"
            field.querySelector(`.t${t + 1}-green`).innerHTML += result
        }
        
        t += 1
    }

}

async function displayMatch(button) {
    matchesDisplay.style.display = "none"
    matchDetails.style.display = "flex"

    let data = await fetchData()

    let firstDiv = button.querySelector("div").querySelector("div")
    let team1 = firstDiv.querySelector("figure").querySelector("img").getAttribute("alt")
    let team2 = firstDiv.querySelectorAll("figure")[1].querySelector("img").getAttribute("alt")
    let result = ""

    let stageName = button.querySelector(".stage-name").textContent
    let groupName = button.querySelector(".group-name").textContent
    
    let stage = ""
    if (button.querySelector(".stage-name").textContent == "Group Stage") {
        stage = "group"
    } else { stage = "knockout" }

    const footballField =`
        <div id='football-field'>
        <div class='white-border'>

        <div class='left-green'>
        <div class='penalty-area'><div class='goal-area'></div></div>
        <div class='penalty-arc'>)</div>
        </div>

        <div class='t1-green'></div>

        <div class='inner-green'>
        <div class='halfway-line'></div>
        <div class='centre-circle'><div class='centre-circle-hollow'><div class='halfway-line'></div></div></div>
        <div class='halfway-line'></div>
        </div>  

        <div class='t2-green'></div>

        <div class='right-green'>
        <div class='penalty-arc'>(</div>
        <div class='penalty-area'><div class='goal-area'></div></div>
        </div>

        </div>
        </div>`

    for (let match of data.matches[stage]) {
        if (match.team1 == team1 && match.team2 == team2) {
            result += `<div class='top-row'><div>${await getFlag(match.team1, 180, 120)}<p class='team-name'>${match.team1}</p><div>${getGoals(match, 0)}</div></div>`
            result += `<div class='match-score'><p>${match.score}</p></div>`
            result += `<div>${await getFlag(match.team2, 180, 120)}<p class='team-name'>${match.team2}</p><div>${getGoals(match, 1)}</div></div></div>`


            result += `<div class='second-row'>`
            result += `<div><p>${stageName}</p>`
            if (groupName){result += "|"}
            result += `<p>${groupName}</p></div><p>Date: ${match.date}</p><p>Venue: ${match.stadium}</p></div>`

            result += `<div class='lineup'><div class='team-subs'>`
            for (let t = 0; t <= 1; t++){
                result += `<div class='team${t + 1}-subs'>${await getFlag(match[`team${t + 1}`])}<p>Manager: ${match.managers[t]}</p><p>Substitutes:</p>`

                for (let player of match.substitutes[t]){
                    result += `<div class='player-tag'><p><b>${player.slice(0,2)}</b>${player.slice(2)}</p><div class='triangleUp'></div></div>`
                }
                result += "</div>"
            }
            result += "</div>"

            result += `${footballField}</div>`
            matchDetails.innerHTML += result
            getPlayers(match)
            break
        }
    }

    
}

async function displayMatch2(button) {
    if (matchOverlay.style.display == "flex"){
        for (let div of matchOverlay.querySelectorAll("div")) {
            div.remove()
        }
    }
    matchOverlay.style.display = "flex"
    let data = await fetchData()

    let firstDiv = button.querySelector("div").querySelector("div")
    let team1 = firstDiv.querySelector("figure").querySelector("img").getAttribute("alt")
    let team2 = firstDiv.querySelectorAll("figure")[1].querySelector("img").getAttribute("alt")
    let result = ""

    let stageName = button.querySelector(".stage-name").textContent
    let groupName = button.querySelector(".group-name").textContent
    
    let stage = ""
    if (button.querySelector(".stage-name").textContent == "Group Stage") {
        stage = "group"
    } else { stage = "knockout" }

    for (let match of data.matches[stage]) {
        if (match.team1 == team1 && match.team2 == team2) {
            result += `<div class='top-row'><div>${await getFlag(match.team1, 180, 120)}<p class='team-name'>${match.team1}</p><div>${getGoals(match, 0)}</div></div>`
            result += `<div class='match-score'><p>${match.score}</p></div>`
            result += `<div>${await getFlag(match.team2, 180, 120)}<p class='team-name'>${match.team2}</p><div>${getGoals(match, 1)}</div></div></div>`


            result += `<div class='second-row'>`
            result += `<div><p>${stageName}</p>`
            if (groupName){result += "|"}
            result += `<p>${groupName}</p></div><p>Date: ${match.date}</p><p>Venue: ${match.stadium}</p></div>`
            break
        }
    }

    matchOverlay.innerHTML += result
}

function matchesBack() {
    matchDetails.style.display = "none"
    matchOverlay.style.display = "none"
    matchesDisplay.style.display = "flex"

    for (let div of matchDetails.querySelectorAll("div")) {
        div.remove()
    }
    for (let div of matchOverlay.querySelectorAll("div")) {
        div.remove()
    }
}